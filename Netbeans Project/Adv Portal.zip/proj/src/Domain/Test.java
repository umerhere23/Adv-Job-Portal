/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Domain;

/**
 *
 * @author Umer
 */
public class Test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Userinterface<String> test;
        test = new Validator<String>();
 test.add("Umer"); test.add("123");
 test.add("Usman");test.add("1234");
 test.add("Noor");test.add("1235");
        System.out.println( test.search("123"));
      
       System.out.println(test.validate(1)+""+test.validate(0));
              System.out.println(test.validate(2)+""+test.validate(3));

        System.out.println(test.size());
    }
    
}
