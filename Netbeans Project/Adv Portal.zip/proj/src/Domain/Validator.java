/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Domain;

import Domain.Userinterface;



/**
 *
 * @author Umer
 */
public class Validator<T> implements Userinterface<T>{
    protected T[] elements;
    protected T[] password;
    protected int numElements = 0;
     protected int find=0;
     
    int i=0;
     public Validator()
    {
        elements = (T[]) new Object[100];
        password = (T[]) new Object[100];

    }
     
    public T validate(int i){
      T name= null;
      name= elements[i];
      return name;
}
     public boolean add(T element){
            elements[numElements] = element;
            numElements++;
            return true;
            
        }
    public boolean  search(T target){
        while(find<numElements){
            if(elements[find].equals(target)){
                  System.out.println("index no is"+find);
    return true;
            } 
            else
           find++;
                    
         }
            return false;
    }
   
    public int size(){
        return numElements;
    }

  
}
